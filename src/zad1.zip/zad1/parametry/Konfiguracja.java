package zad1.parametry;

import zad1.symulacja.rob.Instrukcja;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**
 * Klasa zawierająca parametry symulacji wczytane z pliku.
 * <p> Aby móc korzystać z parametów należy, oprócz stworzenia obiektu klasy {@code Konfiguracja}, wywołać funkcję
 * {@code przetwarzajDane}, która odczytuje oraz zapisuje parametry z pliku {@code plik} do atrybutów. Jeśli dane
 * nie zostały przetworzone, gettery nie zwrócą poprawnych dla symulacji danych.</p>
 *
 * @author Katarzyna Mielnik
 */
public class Konfiguracja {

    private boolean czyPrzetworzonoPlik;
    private final File plik;
    private final HashMap<String, Object> parametry;


    public Konfiguracja(File plik) {
        this.plik = plik;
        this.czyPrzetworzonoPlik = false;
        this.parametry = new HashMap<>();
    }

    /**
     * Sprawdza, czy plik z parametrami został przetworzony, a parametry zostały zapisane w konfiguracji.
     *
     * @return prawda, wtedy i tylko wtedy, gdy {@code plik} został poprawnie przetworzony
     */
    public boolean czyWczytanoDane() {
        return this.czyPrzetworzonoPlik;
    }

    /**
     * Przetwarza {@code plik} i zapisuje parametry w mapie {@code parametry}.
     *
     * @throws FileNotFoundException brak pliku
     * @throws BłędneDane            dane są niezgodne z wymaganiami
     * @throws BrakująceParametry    nie wczytano wszystkich wymaganych parametrów
     */
    public void przetwarzajDane() throws FileNotFoundException, BłędneDane, BrakująceParametry {
        if (this.czyPrzetworzonoPlik)
            return;

        Scanner scanner = new Scanner(this.plik);
        int nrLinii = 0;

        while (scanner.hasNextLine()) {
            try {
                przetwarzajLinię(++nrLinii, scanner.nextLine());
            }
            catch (BłędneDane b) {
                scanner.close();
                throw b;
            }
        }

        scanner.close();
        if (!sprawdźPoprawnośćProgramu((ArrayList<Instrukcja>) this.parametry.get("pocz_progr"),
                (ArrayList<Instrukcja>) this.parametry.get("spis_instr")))
            throw new BłędneDane(nrLinii, "Program zawiera instrukcje spoza spisu.");

        if (!czyWczytanoWszystkieParametry())
            throw new BrakująceParametry();

        this.czyPrzetworzonoPlik = true;
    }

    /**
     * Sprawdza, czy wszystkie parametry potrzebne do przeprowadzenia symulacji zostały wczytane do mapy {@code
     * parametry}.
     * Zakłada, że w mapie nie ma kluczy o niepoprawnych nazwach.
     *
     * @return prawda, wtedy i tylko wtedy, gdy wczytano wszystkie niezbędne parametry
     */
    private boolean czyWczytanoWszystkieParametry() {
        String s = PrawidłoweParametry.dajInstancję().znajdźBrakującyParametr(this.parametry);
        return s == null;
    }

    /**
     * Zapisuje parametr z pojedynczej linii.
     *
     * @param nrLinii numer linii, która jest przetwarzana
     * @param linia   linia, która jest przetwarzana
     * @throws BłędneDane jeśli nazwa parametru powtarza się lub jest niepoprawna, jeśli w linii znajdują się dodatkowe
     *                    znaki
     */
    private void przetwarzajLinię(int nrLinii, String linia) throws BłędneDane {
        Scanner lineScanner = new Scanner(linia);
        String nazwaParametru = lineScanner.next();

        if (this.parametry.containsKey(nazwaParametru)) {
            throw new BłędneDane(nrLinii, "Powtarzający się parametr");
        }

        // Działanie w zależności od nazwy parametru.
        try {
            if (PrawidłoweParametry.dajInstancję().sprawdźParametryInt(nazwaParametru))
                wczytajInt(nazwaParametru, lineScanner, nrLinii);

            else if (PrawidłoweParametry.dajInstancję().sprawdźParametryDouble(nazwaParametru))
                wczytajDouble(nazwaParametru, lineScanner, nrLinii);

            else if (PrawidłoweParametry.dajInstancję().sprawdźString(nazwaParametru))
                this.parametry.put(nazwaParametru, utwórzListęInstrukcji(lineScanner.next()));

            else
                throw new BłędneDane(nrLinii, "Niepoprawna nazwa parametru.");
        }
        catch (BłędneDane b) {
            lineScanner.close();
            throw b;
        }

        boolean zaDużoArgumentów = lineScanner.hasNext();
        lineScanner.close();
        // W przypadku, gdy w linii znajduje się coś jeszcze, a nie powinno.
        if (zaDużoArgumentów)
            throw new BłędneDane(nrLinii, "Nieprawidłowa liczba parametrów w linii.");
    }

    /**
     * Wczytuje parametr typu {@code int}.
     *
     * @param parametr nazwa parametru
     * @param sc       obiekt klasy {@code Scanner}
     * @param nrLinii  numer linii, z której parametr jest wczytywany
     * @throws BłędneDane kiedy wartość parametru nie jest typu {@code int} lub nie mieści się w poprawnym zakresie
     */
    private void wczytajInt(String parametr, Scanner sc, int nrLinii) throws BłędneDane {
        if (!sc.hasNextInt())
            throw new BłędneDane(nrLinii, "Niepoprawny typ.");

        int wartość = sc.nextInt();
        if (!PrawidłoweParametry.dajInstancję().sprawdźZakresWartości(wartość))
            throw new BłędneDane(nrLinii, "Wartość wykracza poza zakres.");

        this.parametry.put(parametr, wartość);
    }

    /**
     * Wczytuje parametr typu {@code double}.
     *
     * @param parametr nazwa parametru
     * @param sc       obiekt klasy {@code Scanner}
     * @param nrLinii  numer linii, z której parametr jest wczytywany
     * @throws BłędneDane kiedy wartość parametru nie jest typu {@code double} lub nie mieści się w poprawnym zakresie
     */
    private void wczytajDouble(String parametr, Scanner sc, int nrLinii) throws BłędneDane {
        if (!sc.hasNextDouble())
            throw new BłędneDane(nrLinii, "Niepoprawny typ.");

        double wartość = sc.nextDouble();
        if (!PrawidłoweParametry.dajInstancję().sprawdźZakresWartości(wartość))
            throw new BłędneDane(nrLinii, "Wartość wykracza poza zakres.");

        this.parametry.put(parametr, wartość);
    }

    /**
     * Tworzy listę znaków reprezentujących instrukcje.
     *
     * @param s ciąg znaków
     * @return lista znaków
     * @throws BłędneDane pewien znak nie reprezentuje żadnej instrukcji.
     */
    private ArrayList<Instrukcja> utwórzListęInstrukcji(String s) throws BłędneDane {
        ArrayList<Instrukcja> instrukcje = new ArrayList<>();

        for (int i = 0; i < s.length(); i++) {
            if (PrawidłoweParametry.dajInstancję().sprawdźPoprawnośćInstrukcji(s.charAt(i)))
                instrukcje.add(Instrukcja.dajInstrukcję(s.charAt(i)));
            else
                throw new BłędneDane(s.charAt(i));
        }
        return instrukcje;
    }

    /**
     * Sprawdza, czy początkowy program zawiera instrukcje wyłącznie ze spisu instrukcji.
     *
     * @param program początkowy program robów
     * @param spis    spis instrukcji dopuszczalnych w symulacji
     * @return prawda, wtedy i tylko wtedy, gdy każdy znak z {@code program} zawiera się w {@code spis}
     */
    private boolean sprawdźPoprawnośćProgramu(ArrayList<Instrukcja> program, ArrayList<Instrukcja> spis) {
        for (Instrukcja i : program) {
            if (!spis.contains(i))
                return false;
        }
        return true;
    }


    public int IleTur() {
        if (!this.czyPrzetworzonoPlik) return -1;
        return (int) this.parametry.get("ile_tur");
    }

    public int PoczIleRobów() {
        if (!this.czyPrzetworzonoPlik) return -1;
        return (int) this.parametry.get("pocz_ile_robów");
    }

    public ArrayList<Instrukcja> PoczProgr() {
        if (!this.czyPrzetworzonoPlik) return null;
        return (ArrayList<Instrukcja>) this.parametry.get("pocz_progr");
    }

    public int poczEnergia() {
        if (!this.czyPrzetworzonoPlik) return -1;
        return (int) this.parametry.get("pocz_energia");
    }

    public int ileDajeJedzenie() {
        if (!this.czyPrzetworzonoPlik) return -1;
        return (int) this.parametry.get("ile_daje_jedzenie");
    }

    public int ileRośnieJedzenie() {
        if (!this.czyPrzetworzonoPlik) return -1;
        return (int) this.parametry.get("ile_rośnie_jedzenie");
    }

    public double prPowielenia() {
        if (!this.czyPrzetworzonoPlik) return -1;
        return (double) this.parametry.get("pr_powielenia");
    }

    public int kosztTury() {
        if (!this.czyPrzetworzonoPlik) return -1;
        return (int) this.parametry.get("koszt_tury");
    }

    public double ułamekEnergiiRodzica() {
        if (!this.czyPrzetworzonoPlik) return -1;
        return (double) this.parametry.get("ułamek_energii_rodzica");
    }

    public int limitPowielania() {
        if (!this.czyPrzetworzonoPlik) return -1;
        return (int) this.parametry.get("limit_powielania");
    }

    public double prUsunięciaInstr() {
        if (!this.czyPrzetworzonoPlik) return -1;
        return (double) this.parametry.get("pr_usunięcia_instr");
    }

    public double prDodaniaInstr() {
        if (!this.czyPrzetworzonoPlik) return -1;
        return (double) this.parametry.get("pr_dodania_instr");
    }

    public double prZmianyInstr() {
        if (!this.czyPrzetworzonoPlik) return -1;
        return (double) this.parametry.get("pr_zmiany_instr");
    }

    public int coIleWypisz() {
        if (!this.czyPrzetworzonoPlik) return -1;
        return (int) this.parametry.get("co_ile_wypisz");
    }

    public ArrayList<Instrukcja> spisInstrukcji() {
        if (!this.czyPrzetworzonoPlik) return null;
        return (ArrayList<Instrukcja>) this.parametry.get("spis_instr");
    }
}
