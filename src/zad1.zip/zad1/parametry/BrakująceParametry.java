package zad1.parametry;

/**
 * Wyjątek zgłaszany, gdy w pliku z parametrami nie ma wszystkich wymaganych parametrów.
 * @see PrawidłoweParametry
 */
public class BrakująceParametry extends Exception{

    public BrakująceParametry() {
        super("Nie wczytano wszystkich parametrów.");
    }
}
