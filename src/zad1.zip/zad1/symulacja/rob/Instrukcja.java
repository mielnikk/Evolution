package zad1.symulacja.rob;

import zad1.symulacja.świat.Plansza;

/**
 * Reprezentacja instrukcji. <p>Każda wartość enumeratora odpowiada poprawnej instrukcji, która może pojawić się w
 * spisie instrukcji. </p>
 *
 * @see zad1.parametry.PrawidłoweParametry
 * @see Rob
 */
public enum Instrukcja {
    IDŹ('i'),
    JEDZ('j'),
    WĄCHAJ('w'),
    LEWO('l'),
    PRAWO('p');

    private final char odpowiadającaLitera;

    Instrukcja(char c) {
        this.odpowiadającaLitera = c;
    }

    /**
     * Zwraca instrukcję oznaczaną danym znakiem. Jeśli taka nie istnieje, zwraca {@code null}.
     */
    public static Instrukcja dajInstrukcję(char c) {
        for (Instrukcja instr : Instrukcja.values()) {
            if (instr.odpowiadającaLitera == c)
                return instr;
        }
        return null;
    }

    void wykonajInstrukcję(Rob rob, Plansza plansza) {
        switch (this) {
            case IDŹ:
                rob.idź(plansza);
                break;
            case WĄCHAJ:
                rob.wąchaj(plansza);
                break;
            case JEDZ:
                rob.jedz(plansza);
                break;
            case PRAWO:
                rob.skręćWPrawo();
                break;
            case LEWO:
                rob.skręćWLewo();
                break;
        }
    }
}
