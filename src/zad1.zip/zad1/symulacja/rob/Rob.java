package zad1.symulacja.rob;

import zad1.parametry.Konfiguracja;
import zad1.symulacja.świat.przestrzenne.Współrzędne;
import zad1.symulacja.świat.przestrzenne.Kierunek;
import zad1.symulacja.świat.Plansza;

import java.util.ArrayList;
import java.util.Random;

public class Rob {
    /**
     * Liczba tur, w których rob był aktywny. Rob, który powstał w danej turze ma wiek 0.
     */
    private int wiek;
    private int energia;
    private boolean czyPowieliSię;
    private final ArrayList<Instrukcja> program;
    private Kierunek kierunek;
    private Współrzędne współrzędne;

    private final int kosztTury;
    private final double ułamekEnergiiRodzica;
    private final int limitPowielania;
    private final double prPowielenia;

    private final double prUsunięciaInstr;
    private final double prZmianyInstr;
    private final double prDodaniaInstr;
    private final ArrayList<Instrukcja> spisInstr;


    public Rob(Konfiguracja konfiguracja, Plansza plansza) {
        this.wiek = 0;
        this.energia = konfiguracja.poczEnergia();
        this.program = konfiguracja.PoczProgr();
        this.kosztTury = konfiguracja.kosztTury();
        this.ułamekEnergiiRodzica = konfiguracja.ułamekEnergiiRodzica();
        this.limitPowielania = konfiguracja.limitPowielania();
        this.prPowielenia = konfiguracja.prPowielenia();
        this.prUsunięciaInstr = konfiguracja.prUsunięciaInstr();
        this.prZmianyInstr = konfiguracja.prZmianyInstr();
        this.prDodaniaInstr = konfiguracja.prDodaniaInstr();
        this.spisInstr = konfiguracja.spisInstrukcji();
        this.czyPowieliSię = losujSzansePowielenia();
        // Początkowa pozycja oraz kierunek są losowe.
        this.współrzędne = plansza.wylosujPozycjęNaPlanszy();
        this.kierunek = Kierunek.dajLosowyKierunek();
    }

    /**
     * Tworzy nowego roba na podstawie przekazanych parametrów.
     * <p> Podczas powielania rob - rodzic tworzy nowego roba przekazując mu wartości atrybutów.</p>
     *
     * @see #powiel
     */
    private Rob(int energia, ArrayList<Instrukcja> program, Kierunek kierunek, Współrzędne współrzędne, int kosztTury,
                double ułamekEnergiiRodzica, int limitPowielania, double prPowielenia, double prUsunięciaInstr,
                double prZmianyInstr, double prDodaniaInstr, ArrayList<Instrukcja> spisInstr) {
        this.wiek = 0;
        this.energia = energia;
        this.program = program;
        this.współrzędne = współrzędne;
        this.kierunek = kierunek;
        this.kosztTury = kosztTury;
        this.ułamekEnergiiRodzica = ułamekEnergiiRodzica;
        this.limitPowielania = limitPowielania;
        this.prPowielenia = prPowielenia;
        this.prUsunięciaInstr = prUsunięciaInstr;
        this.prZmianyInstr = prZmianyInstr;
        this.prDodaniaInstr = prDodaniaInstr;
        this.spisInstr = spisInstr;
    }


    public boolean czyŻywy() {
        return this.energia >= 0;
    }

    /**
     * Wykonuje instrukcję z programu roba ({@code program}) zapisaną pod indeksem {@code index}.
     *
     * @param index   indeks instrukcji
     * @param plansza plansza, na której znajduje się rob
     */
    public void wykonajInstrukcję(int index, Plansza plansza) {
        this.program.get(index).wykonajInstrukcję(this, plansza);
    }

    /**
     * Zjada jedzenie z obecnego pola.
     *
     * @param plansza plansza, na której znajduje się rob
     */
    private void zjedzNaObecnymPolu(Plansza plansza) {
        this.energia += plansza.zjedzJedzenieZPola(this.współrzędne);
    }

    /**
     * Przechodzi o jedno pole zgodnie ze swoim kierunkiem oraz zjada jedzenie z nowego pola.
     *
     * @param plansza plansza, na której znajduje się rob
     */
    void idź(Plansza plansza) {
        this.współrzędne = plansza.obliczWspółrzędne(this.współrzędne, this.kierunek);
        if (plansza.czyPolePosiadaJedzenie(this.współrzędne))
            this.zjedzNaObecnymPolu(plansza);
    }

    /**
     * Szuka jedzenia na czterech najbliższych polach obok oraz po przekątnej. Przechodzi na pole z jedzeniem
     * i zjada z niego jedzenie.
     *
     * @param plansza plansza, na której znajduje się rob
     */
    void jedz(Plansza plansza) {
        Współrzędne współrzędne = null;
        boolean czyZnaleziono = false;
        pętla:
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                if (i == 0 && j == 0)
                    continue;
                współrzędne = plansza.obliczWspółrzędne(this.współrzędne.X() + i, this.współrzędne.Y() + j);
                if (plansza.czyPolePosiadaJedzenie(współrzędne)) {
                    czyZnaleziono = true;
                    break pętla;
                }
            }
        }
        if (czyZnaleziono) {
            this.współrzędne = współrzędne;
            this.zjedzNaObecnymPolu(plansza);
        }
    }

    /**
     * Obraca roba w kierunku jednego z czterech sąsiednich pól, jeśli znajduje się na nim jedzenie.
     *
     * @param plansza plansza, na której znajduje się rob
     */
    void wąchaj(Plansza plansza) {
        for (int i = 0; i < 4; i++) {
            this.kierunek = this.kierunek.obróćWPrawo();
            Współrzędne współrzędne = plansza.obliczWspółrzędne(this.współrzędne, this.kierunek);
            if (plansza.czyPolePosiadaJedzenie(współrzędne))
                break;
        }
    }

    /**
     * Obraca roba w lewo o 90 stopni.
     */
    void skręćWLewo() {
        this.kierunek = this.kierunek.obróćWLewo();
    }

    /**
     * Obraca roba w prawo o 90 stopni.
     */
    void skręćWPrawo() {
        this.kierunek = this.kierunek.obróćWPrawo();
    }

    /**
     * Wykonuje program roba do końca, lub do momentu, w którym zabraknie mu energii.
     *
     * @param plansza plansza, na której znajduje się rob
     */
    public void wykonajProgram(Plansza plansza) {
        int index = 0;
        while (this.energia >= 0 && this.program.size() > index) {
            wykonajInstrukcję(index, plansza);
            this.energia--;
            index++;
        }
    }

    /**
     * Zmienia stan roba wynikający z rozpoczęcia nowej tury. Rozpoczyna wykonywanie programu roba.
     *
     * @param plansza plansza, na której znajduje się rob
     */
    public void nowaTura(Plansza plansza) {
        this.wiek++;
        this.energia = this.energia - this.kosztTury;
        wykonajProgram(plansza);
        this.czyPowieliSię = losujSzansePowielenia() && this.energia >= this.limitPowielania;
    }

    private boolean losujSzansePowielenia() {
        Random random = new Random();
        return random.nextDouble() <= this.prPowielenia;
    }

    /**
     * Zmienia (mutuje) program nowego roba z ustalonym prawdopodobieństwem.
     *
     * @param program program nowego roba
     */
    private void mutujProgram(ArrayList<Instrukcja> program) {
        Random random = new Random();

        if (random.nextDouble() <= this.prUsunięciaInstr && program.size() > 0)
            program.remove(program.size() - 1);

        if (random.nextDouble() <= this.prDodaniaInstr) {
            Instrukcja losowaInstrukcja = this.spisInstr.get(random.nextInt(this.spisInstr.size()));
            program.add(losowaInstrukcja);
        }

        if (random.nextDouble() <= this.prZmianyInstr && program.size() > 0) {
            int losowaPozycja = random.nextInt(program.size());
            program.set(losowaPozycja, this.spisInstr.get(random.nextInt(this.spisInstr.size())));
        }
    }

    /**
     * Tworzy program nowego roba.
     */
    private ArrayList<Instrukcja> utwórzProgramPotomka() {
        ArrayList<Instrukcja> programPotomka = (ArrayList<Instrukcja>) this.program.clone();
        mutujProgram(programPotomka);
        return programPotomka;
    }

    /**
     * Powiela roba.
     * <p>Nowy rob dostaje zmutowaną kopię programu rodzica oraz część energii rodzica. Atrybuty wynikające z
     * konfiguracji są takie same u obu robów. </p>
     *
     * @return nowy rob
     */
    public Rob powiel() {
        if (!czyPowieliSię || this.energia < this.limitPowielania) return null;

        ArrayList<Instrukcja> programPotomka = utwórzProgramPotomka();
        int energiaPotomka = (int) (((double) this.energia) * this.ułamekEnergiiRodzica);
        this.energia -= energiaPotomka;
        return new Rob(energiaPotomka, programPotomka, this.kierunek.przeciwny(), this.współrzędne, this.kosztTury,
                this.ułamekEnergiiRodzica, this.limitPowielania, this.prPowielenia, this.prUsunięciaInstr,
                this.prZmianyInstr, this.prDodaniaInstr, this.spisInstr);
    }

    /**
     * Sprawdza, czy w obecnej turze rob powieli się.
     */
    public boolean czyPowieliSię() {
        return this.czyPowieliSię;
    }

    public int dajDługośćProgramu() {
        return this.program.size();
    }

    public int dajWiek() {
        return this.wiek;
    }

    public int dajWartośćEnergii() {
        return this.energia;
    }

    /**
     * Tworzy opis stanu roba
     */
    @Override
    public String toString() {
        return "Rob: " + "wiek: " + this.wiek + ", " + "energia: " + this.energia + ", " +
                "pozycja " + "(" + this.współrzędne.X() + ", " + this.współrzędne.Y() + ")";
    }
}
