package zad1.symulacja.świat;

/**
 * Wyjątek zgłaszany, gdy w pliku z planszą znajdują się wiersze nierównej długości.
 */
public class NierówneWiersze extends Exception {
    public NierówneWiersze() {
    }
}
