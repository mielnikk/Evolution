package zad1.symulacja.świat.przestrzenne;

import java.util.Random;

/**
 * Implementacja współrzędnych na planszy.
 *
 * @author Katarzyna Mielnik
 */
public class Współrzędne {
    private final int współrzędnaX;
    private final int współrzędnaY;

    public Współrzędne(int x, int y) {
        this.współrzędnaX = x;
        this.współrzędnaY = y;
    }

    public int X() {
        return współrzędnaX;
    }

    public int Y() {
        return współrzędnaY;
    }

    /**
     * Zwraca losowe współrzędne.
     * @param limX wartość, której współrzędna {@code x} nie może przekroczyć
     * @param limY wartość, której współrzędna {@code y} nie może przekroczyć
     */
    public static Współrzędne dajLosoweWspółrzędne(int limX, int limY) {
        Random random= new Random();
        int x = random.nextInt(limX);
        int y = random.nextInt(limY);
        return new Współrzędne(x, y);
    }
}
