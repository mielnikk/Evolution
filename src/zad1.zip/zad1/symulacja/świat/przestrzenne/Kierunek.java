package zad1.symulacja.świat.przestrzenne;

import java.util.Random;

/**
 * Implementacja kierunku na planszy.
 *
 * @author Katarzyna Mielnik
 */
public enum Kierunek {
    GÓRA(0, -1),
    DÓŁ(0, 1),
    PRAWO(1, 0),
    LEWO(-1, 0);

    private final int kierunekX;
    private final int kierunekY;

    Kierunek(int x, int y) {
        this.kierunekX = x;
        this.kierunekY = y;
    }

    public int współrzędnaX() {
        return this.kierunekX;
    }

    public int współrzędnaY() {
        return this.kierunekY;
    }

    private Kierunek kierunekZeWspółrzędnych(int x, int y) {
        for (Kierunek k : Kierunek.values()) {
            if (k.współrzędnaX() == x && k.współrzędnaY() == y)
                return k;
        }
        return null;
    }

    public Kierunek obróćWPrawo() {
        return kierunekZeWspółrzędnych(this.współrzędnaY() * (-1), this.współrzędnaX());
    }

    public Kierunek obróćWLewo() {
        return kierunekZeWspółrzędnych(this.współrzędnaY(), this.współrzędnaX() * (-1));
    }

    public Kierunek przeciwny() {
        return kierunekZeWspółrzędnych(this.kierunekX * (-1), this.kierunekY * (-1));
    }

    public static Kierunek dajLosowyKierunek() {
        Random random = new Random();
        return Kierunek.values()[random.nextInt(4)];
    }

}
