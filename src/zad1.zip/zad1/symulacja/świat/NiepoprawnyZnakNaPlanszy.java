package zad1.symulacja.świat;

/**
 * Wyjątek zgłaszany, gdy w pliku z planszą znajduje się znak, który nie reprezentuje żadnego pola.
 */
public class NiepoprawnyZnakNaPlanszy extends Exception {


    public NiepoprawnyZnakNaPlanszy(char c){
        super("Niepoprawny znak na planszy: " + c + ".");
    }
}
