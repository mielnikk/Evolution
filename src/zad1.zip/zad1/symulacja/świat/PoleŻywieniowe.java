package zad1.symulacja.świat;

public class PoleŻywieniowe extends Pole {
    private boolean czyJedzenieJestDojrzałe;
    private final int ileDajeJedzenie;
    private final int ileRośnieJedzenie;
    private int dojrzałośćJedzenia;

    public PoleŻywieniowe(int ileDajeJedzenie, int ileRośnieJedzenie) {
        this.ileDajeJedzenie = ileDajeJedzenie;
        this.dojrzałośćJedzenia = ileRośnieJedzenie;
        this.ileRośnieJedzenie = ileRośnieJedzenie;
        this.czyJedzenieJestDojrzałe = true;
    }

    public void następnaTura() {
        if (this.czyJedzenieJestDojrzałe) return;

        this.dojrzałośćJedzenia++;
        if (this.dojrzałośćJedzenia == this.ileRośnieJedzenie)
            this.czyJedzenieJestDojrzałe = true;
    }

    public boolean czyPosiadaJedzenie() {
        return this.czyJedzenieJestDojrzałe;
    }

    public int zjedzJedzenie() {
        if (!czyJedzenieJestDojrzałe)
            return 0;
        this.czyJedzenieJestDojrzałe = false;
        this.dojrzałośćJedzenia = 0;
        return this.ileDajeJedzenie;
    }
}
