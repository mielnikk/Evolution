package zad1.symulacja.świat;

public class PustePole extends Pole {

    public void następnaTura(){
    }

    public boolean czyPosiadaJedzenie(){
        return false;
    }
}
