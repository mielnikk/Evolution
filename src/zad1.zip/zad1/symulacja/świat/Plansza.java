package zad1.symulacja.świat;

import zad1.parametry.Konfiguracja;
import zad1.symulacja.świat.przestrzenne.Kierunek;
import zad1.symulacja.świat.przestrzenne.Współrzędne;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Implementacja planszy, na której odbywa się symulacja.
 * <p> Odnośnie współrzędnych na planszy : pole w wierszu wyżej ma mniejszą współrzędną {@code y}. Współrzędna {@code
 * x} rośnie od lewej do prawej strony planszy.
 * </p>
 *
 * @author Katarzyna Mielnik
 */
public class Plansza {
    private final int rozmiarX;
    private final int rozmiarY;
    private int liczbaPólZJedzeniem;
    // Do pola o współrzędnych (x, y) należy odwoływać się pola[y][x].
    // Aby przejść do góry (odpowiednio na dół) należy odwołać się do mniejszej (większej) współrzędnej y
    private final Pole[][] pola;


    private Plansza(Pole[][] pola) {
        this.pola = pola;
        this.rozmiarY = pola.length;
        this.rozmiarX = pola[0].length;
        this.liczbaPólZJedzeniem = 0;
        for (int i = 0; i < pola.length; i++) {
            for (int j = 0; j < pola[i].length; j++) {
                if (pola[i][j].czyPosiadaJedzenie())
                    this.liczbaPólZJedzeniem++;
            }
        }
    }

    /**
     * Tworzy planszę symulacji na podstawie pliku {@code plik}.
     *
     * @param plik         plik z planszą
     * @param konfiguracja konfiguracja symulacji
     * @return plansza utworzona na podstawie pliku
     * @throws FileNotFoundException    nie znaleziono pliku
     * @throws NiepoprawnyZnakNaPlanszy na planszy znajduje się niepoprawny znak
     * @throws NierówneWiersze          wiersze w pliku nie są równej długości
     */
    public static Plansza utwórzPlanszę(File plik, Konfiguracja konfiguracja)
            throws FileNotFoundException, NiepoprawnyZnakNaPlanszy, NierówneWiersze {
        Scanner scanner = new Scanner(plik);
        Pole[][] pola = new Pole[0][]; // Tablica wierszy.
        int rozmiarTablicy = 0;
        int długośćPoprzedniejLinii = 0;
        int numerLinii = 0;
        while (scanner.hasNextLine()) {
            numerLinii++;
            String s = scanner.nextLine();
            Pole[] linia;

            // Próbuje utworzyć kolejny wiersz planszy.
            try {
                linia = utwórzWierszPlanszy(s, konfiguracja);
            }
            catch (NiepoprawnyZnakNaPlanszy n) {
                scanner.close();
                throw n;
            }

            if (numerLinii != 1 && długośćPoprzedniejLinii != s.length()) {
                scanner.close();
                throw new NierówneWiersze();
            }
            długośćPoprzedniejLinii = s.length();

            if (numerLinii - 1 == rozmiarTablicy) {
                rozmiarTablicy = rozmiarTablicy * 2 + 1;
                pola = Arrays.copyOf(pola, rozmiarTablicy);
            }

            pola[numerLinii - 1] = linia;
        }
        scanner.close();
        // Resize tablicy, aby nie było pustych pól.
        pola = Arrays.copyOf(pola, numerLinii);
        return new Plansza(pola);
    }

    /**
     * Tworzy wiersz pól.
     *
     * @param s            zapis wiersza w postaci {@code String}
     * @param konfiguracja konfiguracja symulacji
     * @return tablica typu {@code Pole}
     * @throws NiepoprawnyZnakNaPlanszy w wierszu znajduje się niepoprawny znak
     * @see Pole
     */
    private static Pole[] utwórzWierszPlanszy(String s, Konfiguracja konfiguracja) throws NiepoprawnyZnakNaPlanszy {
        Pole[] wiersz = new Pole[s.length()];
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == ' ')
                wiersz[i] = new PustePole();
            else if (s.charAt(i) == 'x')
                wiersz[i] = new PoleŻywieniowe(konfiguracja.ileDajeJedzenie(), konfiguracja.ileRośnieJedzenie());
            else
                throw new NiepoprawnyZnakNaPlanszy(s.charAt(0));
        }
        return wiersz;
    }

    /**
     * Zwraca współrzędne losowej pozycji na planszy.
     * @see Współrzędne
     */
    public Współrzędne wylosujPozycjęNaPlanszy() {
        return Współrzędne.dajLosoweWspółrzędne(this.rozmiarX, this.rozmiarY);
    }

    /**
     * Oblicza współrzędne sąsiedniego pola, na które wskazuje {@code kierunek}.
     *
     * @param wsp      współrzędne obecnego pola
     * @param kierunek kierunek
     * @return współrzędne pola, które leży w kierunku {@code kierunek} od obecnego pola
     */
    public Współrzędne obliczWspółrzędne(Współrzędne wsp, Kierunek kierunek) {
        return obliczWspółrzędne(wsp.X() + kierunek.współrzędnaX(), wsp.Y() + kierunek.współrzędnaY());
    }

    /**
     * Oblicza współrzędne na planszy na podstawie pozycji w dwóch wymiarach.
     * Współrzędne są obliczane tak, aby nie wskazywały na nieistniejące pole poza planszą.
     * @param pozX pozycja w wierszu
     * @param pozY pozycja w kolumnie
     * @return współrzędne wynikające z pozycji, uwzględniające wymiary planszy
     */
    public Współrzędne obliczWspółrzędne(int pozX, int pozY) {
        int nowaPozX = Math.floorMod(pozX, this.rozmiarX);
        int nowaPozY = Math.floorMod(pozY, this.rozmiarY);
        return new Współrzędne(nowaPozX, nowaPozY);
    }

    /**
     * Sprawdza, czy na polu o współrzędnych {@code wsp} znajduje się jedzenie.
     *
     * @param wsp współrzędne pola
     * @return prawda wtedy i tylko wtedy, gdy na polu znajduje się jedzenie
     */
    public boolean czyPolePosiadaJedzenie(Współrzędne wsp) {
        return this.pola[wsp.Y()][wsp.X()].czyPosiadaJedzenie();
    }

    /**
     * Wprowadza na planszy zmiany wynikające z przejścia do nowej tury.
     * Aktualizuje {@code liczbaPólZJedzeniem} o liczbę pól, na których zregenerowało się jedzenie.
     */
    public void następnaTura() {
        for (int i = 0; i < this.pola.length; i++) {
            for (int j = 0; j < this.pola[i].length; j++) {
                boolean stanPoprzedni = this.pola[i][j].czyPosiadaJedzenie();
                this.pola[i][j].następnaTura();
                if (this.pola[i][j].czyPosiadaJedzenie() != stanPoprzedni) {
                    this.liczbaPólZJedzeniem++;
                }
            }
        }
    }

    /**
     * Przeprowadza procedurę spożycia jedzenia na polu o określonych współrzędnych.
     *
     * @param współrzędnePola współrzędne pola, na którym rob zje jedzenie
     * @return wartość energii, którą daje zjedzone jedzenie
     */
    public int zjedzJedzenieZPola(Współrzędne współrzędnePola) {
        if (this.pola[współrzędnePola.Y()][współrzędnePola.X()].czyPosiadaJedzenie()) {
            this.liczbaPólZJedzeniem--;
            return ((PoleŻywieniowe) this.pola[współrzędnePola.Y()][współrzędnePola.X()]).zjedzJedzenie();
        }
        else return 0;
    }

    /**
     * Sprawdza liczbę pól z jedzeniem. Dla celów statystyczych.
     *
     * @return liczba pól zawierających jedzenie
     */
    public int ilePólPosiadaJedzenie() {
        return liczbaPólZJedzeniem;
    }
}
