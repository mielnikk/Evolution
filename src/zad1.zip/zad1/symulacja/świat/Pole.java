package zad1.symulacja.świat;

/**
 * Pole - pojedyncza składowa planszy.
 */
public abstract class Pole {
    /**
     * Zmienia stan pola wynikający z przejścia do nowej tury.
     */
    public abstract void następnaTura();

    /**
     * Sprawdza, czy w tym momencie pole posiada jedzenie.
     */
    public abstract boolean czyPosiadaJedzenie();
}
