package zad1.symulacja;

import zad1.parametry.Konfiguracja;
import zad1.symulacja.rob.Rob;
import zad1.symulacja.świat.Plansza;

import java.util.ArrayList;
import java.util.Collections;
import java.util.stream.Collectors;

/**
 * Rzeczywistość, w której odbywa się symulacja.
 *
 * @author Katarzyna Mielnik
 */
public class WłaściwaSymulacja {
    private final ArrayList<Rob> roby;
    private final Plansza plansza;
    private final Konfiguracja konfiguracja;
    private final Dane statystyki;

    public WłaściwaSymulacja(Konfiguracja konfiguracja, Plansza plansza) {
        this.konfiguracja = konfiguracja;
        this.plansza = plansza;
        this.roby = new ArrayList<>();
        for (int i = 0; i < konfiguracja.PoczIleRobów(); i++) {
            this.roby.add(new Rob(konfiguracja, plansza));
        }
        this.statystyki = new Dane(this.roby, plansza);
    }

    /**
     * Przeprowadza całą symulację określoną liczbę razy, lub do momentu wyginęcia wszystkich robów.
     */
    public void przeprowadźSymulację() {
        for (int i = 1; i <= this.konfiguracja.IleTur(); i++) {
            this.plansza.następnaTura();
            Collections.shuffle(this.roby);
            ArrayList<Rob> potomkowie = new ArrayList<>();
            for (Rob rob : this.roby) {
                rob.nowaTura(this.plansza);
                if (rob.czyPowieliSię()) {
                    Rob potomek = rob.powiel();
                    potomkowie.add(potomek);
                }
            }
            dodajNoweRoby(potomkowie);
            usuńMartweRoby();
            if (this.roby.size() == 0) {
                System.out.println("Tura " + i + ". Brak żyjących robów. Zakończenie symulacji.");
                break;
            }
            this.statystyki.wypiszStatystyki(i);

            if (i % konfiguracja.coIleWypisz() == 0)
                this.statystyki.wypiszStanSymulacji();
        }
        // Jeśli statystyki nie zostały wypisane po ostatniej turze.
        if (konfiguracja.IleTur() % konfiguracja.coIleWypisz() != 0)
            this.statystyki.wypiszStanSymulacji();
    }

    private void dodajNoweRoby(ArrayList<Rob> noweRoby) {
        this.roby.addAll(noweRoby);
    }

    private void usuńMartweRoby() {
        this.roby.removeAll(this.roby.stream().filter((rob) -> !rob.czyŻywy()).collect(Collectors.toList()));
    }


}
