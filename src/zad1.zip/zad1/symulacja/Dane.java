package zad1.symulacja;

import zad1.symulacja.rob.Rob;
import zad1.symulacja.świat.Plansza;

import java.util.ArrayList;

/**
 * Klasa stworzona w celu wypisywania danych o symulacji.
 *
 * @author Katarzyna Mielnik
 */
class Dane {
    private final ArrayList<Rob> roby;
    private final Plansza plansza;

    public Dane(ArrayList<Rob> roby, Plansza plansza) {
        this.roby = roby;
        this.plansza = plansza;
    }

    void wypiszStanSymulacji() {
        System.out.println("* Stan symulacji.");
        for (Rob rob : this.roby) {
            System.out.println("* " + rob);
        }
    }

    void wypiszStatystyki(int nrTury) {
        String żywność = "żyw: " + plansza.ilePólPosiadaJedzenie();
        System.out.println(nrTury + ", " + żywność + ", " + "roby: " + this.roby.size() + ", " + statystykiProgramu() +
                ", " + statystykiEnergii() + ", " + statystykiWieku());
    }

    String statystykiProgramu() {
        String statDł = "prog: ";
        if (this.roby.size() == 0)
            return statDł += "0/0/0";
        double sumaDł = 0, maxDł = 0, minDł = Double.MAX_VALUE;
        for (Rob rob : this.roby) {
            double długośćProgramuRoba = rob.dajDługośćProgramu();
            sumaDł += długośćProgramuRoba;
            maxDł = Math.max(maxDł, długośćProgramuRoba);
            minDł = Math.min(minDł, długośćProgramuRoba);
        }
        double śrDł = sumaDł / this.roby.size();
        statDł += minDł+ "/" + String.format("%.2f", śrDł) + "/" + maxDł;
        return statDł;
    }

    String statystykiEnergii() {
        if (this.roby.size() == 0)
            return "ener : 0/0/0";

        String statEner = "ener: ";
        double sumaEnergii = 0, maxEnergia = 0, minEnergia = Double.MAX_VALUE;
        for (Rob rob : this.roby) {
            double energia = rob.dajWartośćEnergii();
            sumaEnergii += energia;
            maxEnergia = Math.max(maxEnergia, energia);
            minEnergia = Math.min(minEnergia, energia);
        }
        double śrEnergia = sumaEnergii / this.roby.size();
        statEner += minEnergia + "/" + String.format("%.2f", śrEnergia) + "/" + maxEnergia;
        return statEner;
    }

    String statystykiWieku() {
        String statWiek = "wiek: ";
        if (this.roby.size() == 0)
            return statWiek += "0/0/0";
        double sumaWieku = 0, maxWiek = 0, minWiek = Double.MAX_VALUE;
        for (Rob rob : this.roby) {
            double wiekRoba = rob.dajWiek();
            sumaWieku += wiekRoba;
            maxWiek = Math.max(maxWiek, wiekRoba);
            minWiek = Math.min(minWiek, wiekRoba);
        }
        double śrWiek = sumaWieku / this.roby.size();
        statWiek += minWiek + "/" + String.format("%.2f", śrWiek) + "/" + maxWiek;
        return statWiek;
    }
}
