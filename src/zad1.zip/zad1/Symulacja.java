package zad1;

import zad1.parametry.BrakująceParametry;
import zad1.parametry.BłędneDane;
import zad1.parametry.Konfiguracja;
import zad1.symulacja.WłaściwaSymulacja;
import zad1.symulacja.świat.NiepoprawnyZnakNaPlanszy;
import zad1.symulacja.świat.NierówneWiersze;
import zad1.symulacja.świat.Plansza;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Zadanie 1: Ewolucja, czyli niech programy piszą się same.
 * <p>Tworzy nową symulowaną rzeczywistość na podstawie konfiguracji i planszy. Przeprowadza symulację. </p>
 *
 * @author Katarzyna Mielnik
 */
public class Symulacja {

    public static void main(String[] args) throws FileNotFoundException {
        Konfiguracja konfiguracja;
        Plansza plansza;

        if (args.length < 2) {
            System.out.println("Należy podać dwa pliki.");
            return;
        }

        File plikParametry = new File(args[0]);
        try {
            konfiguracja = new Konfiguracja(plikParametry);
            konfiguracja.przetwarzajDane();
        }
        catch (FileNotFoundException | BłędneDane | BrakująceParametry e) {
            System.out.println(e.getMessage());
            return;
        }

        File plikPlansza = new File(args[1]);
        try {
            plansza = Plansza.utwórzPlanszę(plikPlansza, konfiguracja);
        }
        catch (NiepoprawnyZnakNaPlanszy | NierówneWiersze e) {
            System.out.println(e.getMessage());
            return;
        }

        WłaściwaSymulacja s = new WłaściwaSymulacja(konfiguracja, plansza);
        s.przeprowadźSymulację();
    }
}
